#!/bin/bash
## Import the shell functions to create Regular Expressions expressing constraints
. ./constraintsFunctions.cfg
. ./libs.cfg

function string_join() {
	sep=$1
	chars=$2[@]
	chars=("${!chars}")

	for char in "${chars[@]}"
	 do
	  joint_string="${joint_string}$sep$char"
	 done

#	echo ${joint_string:1}
	echo ${joint_string:1}
}

## Runtime environment constants
MAINCLASS="minerful.MinerFulTracesMakerStarter"
DEBUGLEVEL="none"
MEMORY_MAX="2048m"
JARFILE="MINERful.jar"

## Command constants
DO_TEST_ALPHABET=true
DO_TEST_TRACE_LENGTH=true
DO_TEST_LOG_SIZE=true

## Other constants
OUTPUT_LANGUAGE="mxml"
OUTPUT_DIR="logs"

## Patterns
FILE_PATTERN="$OUTPUT_DIR/alpha_%d_minlen_%d_maxlen_%d_size_%d.$OUTPUT_LANGUAGE"
INVOKE_PATTERN="java -Xmx$MEMORY_MAX -cp $JARFILE $MAINCLASS -d $DEBUGLEVEL -oE $OUTPUT_LANGUAGE -oLF %s -a %s -m %d -M %d -s %d -r %s"

## Global variables
declare_constraints_array=(
#Init(examine patient)
 `Init e`
#AlternatePrecedence(check X ray risk, perform X ray)
 `AlternatePrecedence k x`
#Precedence(perform X ray, perform reposition)
 `Precedence x r`
#Precedence(perform X ray, apply cast)
 `Precedence x a`
#Succession(apply cast, remove cast)
 `Succession a t`
#Precedence(perform X ray, perform surgery)
 `Precedence x s`
#Response(perform surgery, prescribe rehabilitation)
 `Response s h`
)
declare_model_string="`string_join '" "' declare_constraints_array`\""

log_alph_array=(e k x r a t s h) # 8 chrs
# a = apply cast
# e = examine patient
# h = prescribe rehabilitation
# k = check X ray risk
# r = perform reposition
# s = perform surgery
# t = remove cast
# x = perform X ray
log_alph_string="`string_join ':' log_alph_array`"
add_log_alph_array=(0 1 2 3 4 5 6 7 8 9 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z b c d f g i)

add_log_alph_string_array[0]=${add_log_alph_array[0]}
for (( alph=1; alph<${#add_log_alph_array[*]}; alph++ ))
 do
  add_log_alph_string_array[alph]="${add_log_alph_string_array[alph-1]}:${add_log_alph_array[alph]}"
 done

testbed_size_array=(100 200 400 800 1600 3200 6400)
strlen_min_array=(8 16 24 32 40 48)
strlen_max_array=(8 16 24 32 40 48)

## Defaults
default_alphabet="$log_alph_string"
default_testbed_size=${testbed_size_array[ 3 ]}
default_strlen_min=${strlen_min_array[ 2 ]}
default_strlen_max=${strlen_max_array[ 2 ]}

## Running parameters
#alphabet_par="$default_alphabet"
#testbed_size_par="$default_testbed_size"
#strlen_min_par="$default_strlen_min"
#strlen_max_par="$default_strlen_max"
#model_string_par="$declare_model_string"

## Run!
#outfile_string="\"`printf "$FILE_PATTERN" "${#log_alph_array[*]}" "$strlen_min_par" "$strlen_max_par" "$testbed_size_par"`\""
#invocatio_string=`printf "$INVOKE_PATTERN" "$outfile_string" "$alphabet_par" "$strlen_min_par" "$strlen_max_par" "$testbed_size_par" "$model_string_par"`

if $DO_TEST_ALPHABET
 then
  for (( alph=0; alph<${#add_log_alph_string_array[*]}; alph=`expr $alph + 8` ))
   do
    # Running parameters
    if [ $alph -gt 0 ]
     then
    alphabet_par="${log_alph_string}:${add_log_alph_string_array[alph-1]}"
     else
    alphabet_par="${log_alph_string}"
    fi
    testbed_size_par="$default_testbed_size"
    strlen_min_par="$default_strlen_min"
    strlen_max_par="$default_strlen_max"
    model_string_par="$declare_model_string"
    
    log_alph_len=`expr ${#log_alph_array[*]} + $alph`
    
    outfile_string="\"`printf "$FILE_PATTERN" "$log_alph_len" "$strlen_min_par" "$strlen_max_par" "$testbed_size_par"`\""
    invocatio_string=`printf "$INVOKE_PATTERN" "$outfile_string" "$alphabet_par" "$strlen_min_par" "$strlen_max_par" "$testbed_size_par" "$model_string_par"`

    echo "Running:"
    echo "$invocatio_string"
    echo "..."
    eval "$invocatio_string"
    echo "...Done"
   done
fi

if $DO_TEST_TRACE_LENGTH
 then
  for (( min=0; min<${#strlen_min_array[*]}; min++ ))
   do
    # Running parameters
    alphabet_par="$default_alphabet"
    testbed_size_par="$default_testbed_size"
    strlen_min_par="${strlen_min_array[ min ]}"
#    strlen_max_par="${strlen_max_array[ max ]}"
    strlen_max_par="${strlen_max_array[ min ]}"
    model_string_par="$declare_model_string"

    log_alph_len="${#log_alph_array[*]}"

    outfile_string="\"`printf "$FILE_PATTERN" "$log_alph_len" "$strlen_min_par" "$strlen_max_par" "$testbed_size_par"`\""
    invocatio_string=`printf "$INVOKE_PATTERN" "$outfile_string" "$alphabet_par" "$strlen_min_par" "$strlen_max_par" "$testbed_size_par" "$model_string_par"`

    echo "Running:"
    echo "$invocatio_string"
    echo "..."
    eval "$invocatio_string"
    echo "...Done"
   done
fi

if $DO_TEST_LOG_SIZE
 then
  for (( num=0; num<${#testbed_size_array[*]}; num++ ))
   do
    # Running parameters
    alphabet_par="$default_alphabet"
    testbed_size_par="${testbed_size_array[$num]}"
    strlen_min_par="$default_strlen_min"
    strlen_max_par="$default_strlen_max"
    model_string_par="$declare_model_string"

    log_alph_len="${#log_alph_array[*]}"

    outfile_string="\"`printf "$FILE_PATTERN" "$log_alph_len" "$strlen_min_par" "$strlen_max_par" "$testbed_size_par"`\""
    invocatio_string=`printf "$INVOKE_PATTERN" "$outfile_string" "$alphabet_par" "$strlen_min_par" "$strlen_max_par" "$testbed_size_par" "$model_string_par"`

    echo "Running:"
    echo "$invocatio_string"
    echo "..."
    eval "$invocatio_string"
    echo "...Done"
   done
fi
